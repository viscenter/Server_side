CTS Universal compiled for Big Table

This is a pre-release distribution of CTS Universal compiled to
use Google's Big Table for back-end storage.  It includes:

* cts3 : an AppEngine application you can either run locally or
install on Google's infrastructure
* xml-tabulator : an application to create tabular data from XML
texts documented in a TextInventory
* CTS Universal.pdf : a user's guide


0) PREREQUISITES
You must have java and Google's Java AppEngine SDK installed.
You probably want to put the AppEngine SDK's bin directory 
on your path for convenience.

1) TO RUN USING GOOGLE'S LOCAL DEV. SERVER
You can run CTS-U with default settings locally using
the development server in the Google SDK. Just run

	dev_appserver.sh cts3

To configure and use your CTS, see the included user's guide 
(CTS Universal.pdf).  Really -- it's not that long.







